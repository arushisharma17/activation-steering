# Nova commands for TSSB bias-only steering

This package is configured for Arushi's Nova environment by default:

```bash
BASE_ROOT=/lustre/hdd/LAS/jannesar-lab/arushi
PROJECT_ROOT=$BASE_ROOT/activation-steering
TSSB_ROOT=$BASE_ROOT/tssb_eval_colab_biasonly
source $BASE_ROOT/myenv/bin/activate
```

The SLURM scripts source `slurm/nova_env.sh`, which sets:

```bash
MPLCONFIGDIR=$BASE_ROOT/matplotlib
XDG_CACHE_HOME=$BASE_ROOT/cache
TRITON_CACHE_DIR=$BASE_ROOT/cache/triton
HF_HOME=$BASE_ROOT
HF_CACHE=$PROJECT_ROOT/models
TRANSFORMERS_CACHE=$PROJECT_ROOT/models
CUDA_LAUNCH_BLOCKING=1
CUDA_VISIBLE_DEVICES=0
```

You can override any path at submit time with `--export=ALL,VAR=value`.

## 0. Unzip and enter project

```bash
cd /lustre/hdd/LAS/jannesar-lab/arushi
unzip -o tssb_eval_colab_biasonly_nova_env.zip
cd tssb_eval_colab_biasonly
mkdir -p logs outputs repos_tssb
```

## 1. Prepare supervised TSSB splits

If you want a bounded test run:

```bash
sbatch --export=ALL,MAX_EXAMPLES=5000,SPLIT_MODE=random slurm/00_prepare_tssb_supervised.sh
```

For full filtered-2:

```bash
sbatch --export=ALL,SPLIT_MODE=random slurm/00_prepare_tssb_supervised.sh
```

If the fetch file already exists and you only want to rebuild eval/splits:

```bash
sbatch --export=ALL,SKIP_FETCH=1,SPLIT_MODE=random slurm/00_prepare_tssb_supervised.sh
```

Expected outputs:

```bash
outputs/tssb_with_full_code.jsonl
outputs/tssb_diff_hunk_eval_all.jsonl
outputs/supervised_all_random/tssb_supervised_train.jsonl
outputs/supervised_all_random/tssb_supervised_dev.jsonl
outputs/supervised_all_random/tssb_supervised_test.jsonl
```

## 2. Smoke test with 1.5B

```bash
sbatch slurm/03_smoke_1p5b.sh
```

## 3. Train 7B supervised bias-only vectors

```bash
sbatch slurm/01_train_bias_only_tssb.sh
```

Common overrides:

```bash
sbatch --export=ALL,MODEL=Qwen/Qwen2.5-Coder-1.5B-Instruct,MAX_LENGTH=1024,OUTPUT_DIR=$PWD/outputs/bias_only_qwen15_tssb slurm/01_train_bias_only_tssb.sh
```

```bash
sbatch --export=ALL,EPOCHS=2,LR=5e-3,EVAL_STEPS=50,SAVE_STEPS=250 slurm/01_train_bias_only_tssb.sh
```

## 4. Generate and evaluate steered model

```bash
sbatch slurm/02_generate_eval_tssb.sh
```

## 5. Generate and evaluate base model, no steering

```bash
sbatch --export=ALL,STEERING=none,PRED_OUT=$PWD/outputs/preds_base_test.jsonl,EVAL_OUT=$PWD/outputs/eval_base_test.json slurm/02_generate_eval_tssb.sh
```

## 6. Inspect logs

```bash
ls -lh logs/
tail -f logs/slurm-tssb-bias-train-<JOBID>.out
```

## Notes

- Data preparation can run without a GPU, but the current prepare script still requests an A100 to match the standard template. If queue time becomes an issue, remove `#SBATCH --gres=gpu:a100` from `00_prepare_tssb_supervised.sh`.
- Training requires a GPU because the full model is loaded and backpropagated through, even though only the steering vectors are trainable.
- The first serious debugging target is whether training saves `outputs/bias_only_qwen_tssb/steering_vectors.pt`.
