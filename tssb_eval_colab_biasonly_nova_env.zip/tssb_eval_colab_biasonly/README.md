# TSSB localized repair → supervised bias-only steering prep

This package turns a TSSB-style JSONL file such as `filtered2.jsonl` into:

1. full-code-enriched examples fetched from GitHub commits,
2. line-level and diff-hunk repair eval files,
3. supervised train/dev/test JSONL files suitable for bias-only steering,
4. optional minimal scripts for supervised bias-only vector training and generation.

The first version of the pipeline crashed on some repositories because `git show` returned non-UTF-8 source files. This version captures Git output as bytes and decodes defensively with UTF-8 / latin-1 / cp1252 fallbacks.

## Quick Colab usage

```bash
unzip -q tssb_eval_colab_biasonly.zip -d /content/
cd /content/tssb_eval_colab_biasonly
python run_colab_pipeline.py --data /content/filtered2.jsonl --max-examples 100 --require-usable
```

For the full dataset, remove `--max-examples`.

Key outputs:

```text
outputs/tssb_with_full_code.jsonl
outputs/tssb_line_repair_eval.jsonl
outputs/tssb_diff_hunk_eval.jsonl
outputs/tssb_context_inspection.md
outputs/dataset_summary.json
outputs/supervised/tssb_supervised_all.jsonl
outputs/supervised/tssb_supervised_train.jsonl
outputs/supervised/tssb_supervised_dev.jsonl
outputs/supervised/tssb_supervised_test.jsonl
outputs/supervised/tssb_supervised_summary.json
```

## Supervised data format

The files in `outputs/supervised/` have one JSON object per line:

```json
{
  "id": "tssb_123",
  "prompt": "You are fixing a small localized bug in a unified diff hunk...",
  "target": "parts = env_var.split('=', 1)",
  "metadata": {
    "project": "ansible",
    "sstub_pattern": "SAME_FUNCTION_MORE_ARGS",
    "repair_family": "api_argument_contract",
    "locality_label": "local_inferable"
  }
}
```

The model should be trained on `prompt + target`, with labels masked over the prompt tokens and CE loss only on the target tokens.

## Why diff-hunk first?

The diff-hunk task is the cleanest first setting for bias-only repair steering:

```text
input: buggy diff hunk with <FILL_FIXED_CODE>
target: developer fixed line
objective: supervised CE on target tokens
```

No tests, compilation, or RL reward loop are needed for the first proof of concept.

## Training minimal supervised bias-only vectors

Install dependencies in your environment:

```bash
pip install torch transformers accelerate
```

Example command:

```bash
python scripts/train_bias_only_tssb.py \
  --model Qwen/Qwen2.5-Coder-7B-Instruct \
  --train-file outputs/supervised/tssb_supervised_train.jsonl \
  --eval-file outputs/supervised/tssb_supervised_dev.jsonl \
  --output-dir outputs/bias_only_qwen_tssb \
  --epochs 1 \
  --batch-size 1 \
  --grad-accum 8 \
  --lr 1e-2 \
  --max-length 2048 \
  --dtype bf16
```

The script freezes all base model parameters and trains only one additive steering vector per decoder layer:

```python
hidden_states = hidden_states + steering_vector[layer]
```

It saves:

```text
outputs/bias_only_qwen_tssb/steering_vectors.pt
outputs/bias_only_qwen_tssb/metadata.json
```

## Generation with trained vectors

```bash
python scripts/generate_with_bias_only.py \
  --model Qwen/Qwen2.5-Coder-7B-Instruct \
  --data outputs/supervised/tssb_supervised_test.jsonl \
  --steering outputs/bias_only_qwen_tssb/steering_vectors.pt \
  --out outputs/preds_bias_only_test.jsonl \
  --max-new-tokens 80 \
  --dtype bf16
```

Baseline generation without steering:

```bash
python scripts/generate_with_bias_only.py \
  --model Qwen/Qwen2.5-Coder-7B-Instruct \
  --data outputs/supervised/tssb_supervised_test.jsonl \
  --out outputs/preds_base_test.jsonl \
  --max-new-tokens 80 \
  --dtype bf16
```

Evaluate:

```bash
python scripts/evaluate_predictions.py \
  --gold outputs/supervised/tssb_supervised_test.jsonl \
  --pred outputs/preds_bias_only_test.jsonl \
  --out outputs/eval_bias_only_test.json
```

## Relationship to corl-team/steering-reasoning

The `corl-team/steering-reasoning` repo trains layer-wise additive vectors for math reasoning with an RL objective. For TSSB, the analogous first step is supervised:

```text
math paper: prompt → sampled reasoning → answer reward → train vectors
TSSB first step: diff hunk prompt → fixed line target → CE loss → train vectors
```

Once this supervised setup works, the next adaptation is to port the dataset into the repo's config-driven training/eval structure or add a supervised trainer in that repo.

## Recommended experiment order

1. Fix/fetch TSSB full code.
2. Build diff-hunk eval files with source-like `target_code`.
3. Prepare project-held-out supervised splits.
4. Train zero-init supervised bias-only vectors.
5. Compare against base generation and TSSB policy prompt.
6. Add contrastive-init bias-only vectors.
7. Analyze per-family and local-inferable subset results.

## Nova / SLURM workflow

This version includes SLURM scripts under `slurm/` for running the whole workflow on Nova with A100 resources.
See [`nova_commands.md`](nova_commands.md) for copy-paste commands.

Recommended Nova sequence:

```bash
# 1. Prepare supervised splits from filtered-2.jsonl
sbatch --export=ALL,ROOT=$PWD,DATA=/path/to/filtered-2.jsonl,MAX_EXAMPLES=5000,SPLIT_MODE=random slurm/00_prepare_tssb_supervised.sh

# 2. Smoke-test with Qwen2.5-Coder-1.5B
sbatch --export=ALL,ROOT=$PWD slurm/03_smoke_1p5b.sh

# 3. Train 7B supervised bias-only vectors
sbatch --export=ALL,ROOT=$PWD slurm/01_train_bias_only_tssb.sh

# 4. Generate/evaluate steered model
sbatch --export=ALL,ROOT=$PWD slurm/02_generate_eval_tssb.sh

# 5. Generate/evaluate base model
sbatch --export=ALL,ROOT=$PWD,STEERING=none,PRED_OUT=$PWD/outputs/preds_base_test.jsonl,EVAL_OUT=$PWD/outputs/eval_base_test.json slurm/02_generate_eval_tssb.sh
```

The bias-only trainer is a standalone supervised implementation of the core intervention used in reasoning-steering work: freeze the base LLM, add one trainable additive hidden-state vector per decoder layer, and train only those vectors. It does not depend on the `corl-team/steering-reasoning` RL training stack.
