#!/usr/bin/env python3
"""Colab-friendly one-command pipeline for TSSB localized repair evaluation.

Stages:
1. Fetch full buggy/fixed files from Git.
2. Build line and diff-hunk repair eval files.
3. Inspect local context.
4. Prepare supervised train/dev/test JSONL for bias-only steering.
"""

import argparse
import subprocess
import sys
from pathlib import Path


def run(cmd):
    print("\n[RUN]", " ".join(cmd), flush=True)
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help="Path to filtered2.jsonl or similar TSSB JSONL file")
    parser.add_argument("--out-dir", default="outputs", help="Output directory")
    parser.add_argument("--repo-dir", default="repos_tssb", help="Directory for cloned repositories")
    parser.add_argument("--max-examples", type=int, default=None, help="Optional max examples for a dry run")
    parser.add_argument("--context-window", type=int, default=8, help="Number of surrounding lines in context inspection")
    parser.add_argument("--require-usable", action="store_true", help="Keep only examples with full-code sanity checks in eval/supervised files")
    parser.add_argument("--split-mode", choices=["project", "random"], default="project", help="Supervised split mode")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    enriched = out_dir / "tssb_with_full_code.jsonl"
    line_eval = out_dir / "tssb_line_repair_eval.jsonl"
    hunk_eval = out_dir / "tssb_diff_hunk_eval.jsonl"
    inspection = out_dir / "tssb_context_inspection.md"
    summary = out_dir / "dataset_summary.json"
    supervised_dir = out_dir / "supervised"

    extract_cmd = [
        sys.executable, "scripts/fetch_full_code.py",
        "--data", args.data,
        "--out", str(enriched),
        "--repo-dir", args.repo_dir,
    ]
    if args.max_examples is not None:
        extract_cmd += ["--max-examples", str(args.max_examples)]
    run(extract_cmd)

    build_cmd = [
        sys.executable, "scripts/build_eval_files.py",
        "--data", str(enriched),
        "--line-out", str(line_eval),
        "--hunk-out", str(hunk_eval),
        "--summary-out", str(summary),
    ]
    if args.require_usable:
        build_cmd.append("--require-usable")
    run(build_cmd)

    inspect_cmd = [
        sys.executable, "scripts/inspect_context.py",
        "--data", str(enriched),
        "--out", str(inspection),
        "--window", str(args.context_window),
        "--max-examples", "100",
    ]
    run(inspect_cmd)

    prep_cmd = [
        sys.executable, "scripts/prepare_supervised_tssb.py",
        "--data", str(hunk_eval),
        "--out-dir", str(supervised_dir),
        "--split-mode", args.split_mode,
        "--seed", str(args.seed),
        "--target-field", "target_code",
    ]
    if args.require_usable:
        prep_cmd.append("--require-usable")
    run(prep_cmd)

    print("\nDone. Key outputs:")
    for p in [enriched, line_eval, hunk_eval, inspection, summary, supervised_dir / "tssb_supervised_train.jsonl", supervised_dir / "tssb_supervised_dev.jsonl", supervised_dir / "tssb_supervised_test.jsonl"]:
        print(" -", p)


if __name__ == "__main__":
    main()
