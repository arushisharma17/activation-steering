#!/usr/bin/env python3
"""Generate predictions from a base model with optional trained bias-only steering vectors."""

import argparse
import json
from pathlib import Path

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer

# Reuse compact versions of the trainer classes.
class SteeringVector(nn.Module):
    def __init__(self, vector):
        super().__init__()
        self.register_buffer("steering_vector", vector.view(1, 1, -1))
    def forward(self, x):
        return x + self.steering_vector.to(dtype=x.dtype, device=x.device)

class DecoderLayerWithSteering(nn.Module):
    def __init__(self, base_layer, vector):
        super().__init__()
        self.base_layer = base_layer
        self.steering = SteeringVector(vector)
    def forward(self, *args, **kwargs):
        out = self.base_layer(*args, **kwargs)
        if isinstance(out, tuple):
            return (self.steering(out[0]),) + out[1:]
        return self.steering(out)
    def __getattr__(self, name):
        try:
            return super().__getattr__(name)
        except AttributeError:
            return getattr(self.base_layer, name)

def find_decoder_layers(model):
    candidates = [
        lambda m: m.model.layers,
        lambda m: m.transformer.h,
        lambda m: m.gpt_neox.layers,
    ]
    for getter in candidates:
        try:
            layers = getter(model)
            if isinstance(layers, nn.ModuleList) and len(layers) > 0:
                return layers
        except Exception:
            pass
    raise RuntimeError("Could not find decoder layers")

def patch_model(model, steering_path):
    obj = torch.load(steering_path, map_location="cpu")
    vectors = obj["steering_vectors"] if isinstance(obj, dict) and "steering_vectors" in obj else obj
    layers = find_decoder_layers(model)
    if len(vectors) != len(layers):
        raise ValueError(f"Vector count {len(vectors)} != layer count {len(layers)}")
    for i, layer in enumerate(layers):
        layers[i] = DecoderLayerWithSteering(layer, vectors[i])

def read_jsonl(path):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--data", required=True, help="JSONL with prompt/target")
    ap.add_argument("--out", required=True)
    ap.add_argument("--steering", default=None, help="Path to steering_vectors.pt")
    ap.add_argument("--max-examples", type=int, default=None)
    ap.add_argument("--max-new-tokens", type=int, default=80)
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--dtype", choices=["auto", "bf16", "fp16", "fp32"], default="auto")
    args = ap.parse_args()

    if args.dtype == "bf16": dtype = torch.bfloat16
    elif args.dtype == "fp16": dtype = torch.float16
    elif args.dtype == "fp32": dtype = torch.float32
    else: dtype = "auto"

    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=dtype, trust_remote_code=True)
    if args.steering:
        patch_model(model, args.steering)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fout:
        for i, ex in enumerate(read_jsonl(args.data)):
            if args.max_examples is not None and i >= args.max_examples:
                break
            prompt = ex["prompt"]
            inputs = tok(prompt, return_tensors="pt").to(device)
            gen_kwargs = {
                "max_new_tokens": args.max_new_tokens,
                "pad_token_id": tok.pad_token_id,
                "eos_token_id": tok.eos_token_id,
            }
            if args.temperature and args.temperature > 0:
                gen_kwargs.update({"do_sample": True, "temperature": args.temperature})
            else:
                gen_kwargs.update({"do_sample": False})
            with torch.no_grad():
                out = model.generate(**inputs, **gen_kwargs)
            new_ids = out[0, inputs["input_ids"].shape[1]:]
            pred = tok.decode(new_ids, skip_special_tokens=True).strip()
            fout.write(json.dumps({
                "id": ex.get("id"),
                "prediction": pred,
                "target": ex.get("target"),
                "metadata": ex.get("metadata", {}),
            }, ensure_ascii=False) + "\n")
            if i % 25 == 0:
                print("generated", i, flush=True)
    print("Wrote", out_path)

if __name__ == "__main__":
    main()
