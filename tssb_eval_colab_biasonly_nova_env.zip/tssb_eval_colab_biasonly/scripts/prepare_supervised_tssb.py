#!/usr/bin/env python3
"""Prepare TSSB diff/line repair JSONL for supervised bias-only steering.

Input is usually outputs/tssb_diff_hunk_eval.jsonl created by build_eval_files.py.
Output format is intentionally simple and library-friendly:
{
  "id": "tssb_123",
  "prompt": "...",
  "target": "fixed code line",
  "metadata": {...}
}
"""

import argparse
import json
import random
from collections import Counter, defaultdict
from pathlib import Path


def read_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def normalize_row(ex, target_field="target_code"):
    target = (ex.get(target_field) or ex.get("target") or ex.get("after") or "").strip()
    prompt = ex.get("prompt", "")
    metadata = {
        "example_id": ex.get("example_id"),
        "project": ex.get("project"),
        "project_url": ex.get("project_url"),
        "file_path": ex.get("file_path"),
        "parent_sha": ex.get("parent_sha"),
        "commit_sha": ex.get("commit_sha"),
        "task_type": ex.get("task_type"),
        "sstub_pattern": ex.get("sstub_pattern"),
        "repair_family": ex.get("repair_family"),
        "locality_label": ex.get("locality_label"),
        "locality_reasons": ex.get("locality_reasons"),
        "full_code_status": ex.get("full_code_status"),
        "usable_for_supervised_repair": ex.get("usable_for_supervised_repair"),
    }
    return {
        "id": ex.get("id") or f"tssb_{ex.get('example_id')}",
        "prompt": prompt,
        "target": target,
        "metadata": metadata,
    }


def filter_rows(rows, args):
    kept = []
    stats = Counter()
    for ex in rows:
        stats["seen"] += 1
        if args.require_usable and not ex.get("usable_for_supervised_repair"):
            stats["drop_not_usable"] += 1
            continue
        if args.locality_label and ex.get("locality_label") != args.locality_label:
            stats[f"drop_locality_not_{args.locality_label}"] += 1
            continue
        if args.repair_family and ex.get("repair_family") != args.repair_family:
            stats[f"drop_family_not_{args.repair_family}"] += 1
            continue
        target = (ex.get(args.target_field) or ex.get("target") or ex.get("after") or "").strip()
        prompt = ex.get("prompt", "")
        if not prompt or not target:
            stats["drop_missing_prompt_or_target"] += 1
            continue
        if len(target) < args.min_target_chars:
            stats["drop_target_too_short"] += 1
            continue
        if args.max_target_chars and len(target) > args.max_target_chars:
            stats["drop_target_too_long"] += 1
            continue
        kept.append(normalize_row(ex, target_field=args.target_field))
        stats["kept"] += 1
    return kept, stats


def random_split(rows, seed, train_frac, dev_frac):
    rng = random.Random(seed)
    rows = list(rows)
    rng.shuffle(rows)
    n = len(rows)
    n_train = int(n * train_frac)
    n_dev = int(n * dev_frac)
    return rows[:n_train], rows[n_train:n_train+n_dev], rows[n_train+n_dev:]


def project_split(rows, seed, train_frac, dev_frac):
    by_project = defaultdict(list)
    for r in rows:
        p = (r.get("metadata") or {}).get("project") or "UNKNOWN"
        by_project[p].append(r)
    projects = list(by_project.keys())
    rng = random.Random(seed)
    rng.shuffle(projects)

    total = len(rows)
    train_target = total * train_frac
    dev_target = total * dev_frac
    train, dev, test = [], [], []
    for p in projects:
        bucket = by_project[p]
        if len(train) < train_target:
            train.extend(bucket)
        elif len(dev) < dev_target:
            dev.extend(bucket)
        else:
            test.extend(bucket)
    rng.shuffle(train); rng.shuffle(dev); rng.shuffle(test)
    return train, dev, test


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Usually outputs/tssb_diff_hunk_eval.jsonl")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--target-field", default="target_code")
    ap.add_argument("--split-mode", choices=["random", "project"], default="project")
    ap.add_argument("--train-frac", type=float, default=0.8)
    ap.add_argument("--dev-frac", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--require-usable", action="store_true")
    ap.add_argument("--locality-label", default=None, help="Optional filter, e.g. local_inferable")
    ap.add_argument("--repair-family", default=None, help="Optional filter, e.g. api_argument_contract")
    ap.add_argument("--min-target-chars", type=int, default=1)
    ap.add_argument("--max-target-chars", type=int, default=500)
    ap.add_argument("--max-examples", type=int, default=None)
    args = ap.parse_args()

    raw = read_jsonl(args.data)
    rows, stats = filter_rows(raw, args)
    if args.max_examples:
        rows = rows[:args.max_examples]

    if args.split_mode == "project":
        train, dev, test = project_split(rows, args.seed, args.train_frac, args.dev_frac)
    else:
        train, dev, test = random_split(rows, args.seed, args.train_frac, args.dev_frac)

    out = Path(args.out_dir)
    write_jsonl(out / "tssb_supervised_all.jsonl", rows)
    write_jsonl(out / "tssb_supervised_train.jsonl", train)
    write_jsonl(out / "tssb_supervised_dev.jsonl", dev)
    write_jsonl(out / "tssb_supervised_test.jsonl", test)

    summary = {
        "input": args.data,
        "target_field": args.target_field,
        "split_mode": args.split_mode,
        "seed": args.seed,
        "filter_stats": dict(stats),
        "counts": {"all": len(rows), "train": len(train), "dev": len(dev), "test": len(test)},
        "families": Counter((r["metadata"].get("repair_family") or "UNKNOWN") for r in rows).most_common(),
        "locality": Counter((r["metadata"].get("locality_label") or "UNKNOWN") for r in rows).most_common(),
        "projects": Counter((r["metadata"].get("project") or "UNKNOWN") for r in rows).most_common(50),
    }
    (out / "tssb_supervised_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False)[:3000])


if __name__ == "__main__":
    main()
