#!/usr/bin/env python3
"""Minimal supervised bias-only steering trainer for TSSB repair.

This is intentionally independent of the corl-team RL training loop. It uses the
same core intervention idea: freeze the base LLM and train one additive hidden
state vector per decoder layer. The objective is supervised CE on the target
fixed line.

Input files should be created by scripts/prepare_supervised_tssb.py.
"""

import argparse
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Tuple

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup


class JsonlRepairDataset(Dataset):
    def __init__(self, path: str, tokenizer, max_length: int = 2048):
        self.rows = []
        self.tokenizer = tokenizer
        self.max_length = max_length
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    self.rows.append(json.loads(line))

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        ex = self.rows[idx]
        prompt = ex["prompt"]
        target = ex["target"].strip()
        eos = self.tokenizer.eos_token or ""
        target_text = target + eos

        prompt_ids = self.tokenizer(prompt, add_special_tokens=False).input_ids
        target_ids = self.tokenizer(target_text, add_special_tokens=False).input_ids
        input_ids = prompt_ids + target_ids
        labels = [-100] * len(prompt_ids) + target_ids

        if len(input_ids) > self.max_length:
            # Keep the end, where the target is. If this truncates all prompt tokens,
            # the example is still usable for CE but less informative.
            input_ids = input_ids[-self.max_length:]
            labels = labels[-self.max_length:]

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.ones(len(input_ids), dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


def collate(batch, pad_token_id: int):
    max_len = max(x["input_ids"].numel() for x in batch)
    input_ids, attention_mask, labels = [], [], []
    for x in batch:
        n = x["input_ids"].numel()
        pad = max_len - n
        input_ids.append(torch.cat([x["input_ids"], torch.full((pad,), pad_token_id, dtype=torch.long)]))
        attention_mask.append(torch.cat([x["attention_mask"], torch.zeros(pad, dtype=torch.long)]))
        labels.append(torch.cat([x["labels"], torch.full((pad,), -100, dtype=torch.long)]))
    return {
        "input_ids": torch.stack(input_ids),
        "attention_mask": torch.stack(attention_mask),
        "labels": torch.stack(labels),
    }


class SteeringVector(nn.Module):
    def __init__(self, hidden_size: int, init_tensor=None):
        super().__init__()
        if init_tensor is None:
            init = torch.zeros(1, 1, hidden_size)
        else:
            init = init_tensor.detach().float().view(1, 1, hidden_size).clone()
        self.steering_vector = nn.Parameter(init)

    def forward(self, x):
        return x + self.steering_vector.to(dtype=x.dtype, device=x.device)


class DecoderLayerWithSteering(nn.Module):
    def __init__(self, base_layer: nn.Module, hidden_size: int, init_tensor=None):
        super().__init__()
        self.base_layer = base_layer
        self.steering = SteeringVector(hidden_size, init_tensor=init_tensor)

    def forward(self, *args, **kwargs):
        out = self.base_layer(*args, **kwargs)
        if isinstance(out, tuple):
            hidden_states = self.steering(out[0])
            return (hidden_states,) + out[1:]
        hidden_states = self.steering(out)
        return hidden_states

    def __getattr__(self, name):
        # Let architecture-specific attributes such as self_attn/mlp/layer_idx pass through.
        try:
            return super().__getattr__(name)
        except AttributeError:
            return getattr(self.base_layer, name)


def find_decoder_layers(model):
    candidates = [
        ("model.layers", lambda m: m.model.layers),
        ("transformer.h", lambda m: m.transformer.h),
        ("gpt_neox.layers", lambda m: m.gpt_neox.layers),
    ]
    for name, getter in candidates:
        try:
            layers = getter(model)
            if isinstance(layers, nn.ModuleList) and len(layers) > 0:
                return name, layers
        except Exception:
            pass
    raise RuntimeError("Could not find decoder layers. Add your architecture to find_decoder_layers().")


def patch_model_with_steering(model, init_path: str = None):
    hidden_size = getattr(model.config, "hidden_size", None) or getattr(model.config, "n_embd", None)
    if hidden_size is None:
        raise RuntimeError("Could not infer hidden size from model.config")

    init_vectors = None
    if init_path:
        obj = torch.load(init_path, map_location="cpu")
        # Accept either {'vectors': {layer_idx: tensor}} or {'steering_vectors': list/tensor}
        if isinstance(obj, dict) and "vectors" in obj:
            init_vectors = obj["vectors"]
        elif isinstance(obj, dict) and "steering_vectors" in obj:
            sv = obj["steering_vectors"]
            init_vectors = {i: v for i, v in enumerate(sv)}
        elif torch.is_tensor(obj):
            init_vectors = {i: obj[i] for i in range(obj.shape[0])}
        else:
            raise RuntimeError(f"Unsupported init vector format in {init_path}")

    layer_name, layers = find_decoder_layers(model)
    for i, layer in enumerate(layers):
        init_tensor = None
        if init_vectors is not None:
            init_tensor = init_vectors.get(i, None) if isinstance(init_vectors, dict) else None
        layers[i] = DecoderLayerWithSteering(layer, hidden_size, init_tensor=init_tensor)
    return layer_name, len(layers), hidden_size


def freeze_except_steering(model):
    for p in model.parameters():
        p.requires_grad = False
    params = []
    for name, p in model.named_parameters():
        if ".steering.steering_vector" in name or "steering_vector" in name:
            p.requires_grad = True
            params.append(p)
    return params


def save_steering_vectors(model, out_dir, metadata):
    vectors = []
    for module in model.modules():
        if isinstance(module, SteeringVector):
            vectors.append(module.steering_vector.detach().cpu().squeeze(0).squeeze(0))
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    torch.save({"steering_vectors": vectors, "metadata": metadata}, out_dir / "steering_vectors.pt")
    (out_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


@torch.no_grad()
def evaluate_loss(model, loader, device):
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    for batch in loader:
        batch = {k: v.to(device) for k, v in batch.items()}
        out = model(**batch)
        # HF returns average loss over non-masked labels. Weight by token count.
        n = (batch["labels"] != -100).sum().item()
        total_loss += out.loss.item() * max(n, 1)
        total_tokens += n
    if total_tokens == 0:
        return float("nan"), float("nan")
    avg = total_loss / total_tokens
    return avg, math.exp(min(avg, 20))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="HF model name/path")
    ap.add_argument("--train-file", required=True)
    ap.add_argument("--eval-file", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=1)
    ap.add_argument("--grad-accum", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-2)
    ap.add_argument("--weight-decay", type=float, default=0.0)
    ap.add_argument("--warmup-ratio", type=float, default=0.03)
    ap.add_argument("--max-length", type=int, default=2048)
    ap.add_argument("--dtype", choices=["auto", "bf16", "fp16", "fp32"], default="auto")
    ap.add_argument("--init-steering", default=None, help="Optional steering_vectors.pt for initialization")
    ap.add_argument("--eval-steps", type=int, default=100)
    ap.add_argument("--save-steps", type=int, default=500)
    args = ap.parse_args()

    if args.dtype == "bf16":
        dtype = torch.bfloat16
    elif args.dtype == "fp16":
        dtype = torch.float16
    elif args.dtype == "fp32":
        dtype = torch.float32
    else:
        dtype = "auto"

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map=None,
        trust_remote_code=True,
    )
    layer_name, n_layers, hidden_size = patch_model_with_steering(model, init_path=args.init_steering)
    trainable_params = freeze_except_steering(model)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.config.use_cache = False
    if hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()

    train_ds = JsonlRepairDataset(args.train_file, tokenizer, max_length=args.max_length)
    eval_ds = JsonlRepairDataset(args.eval_file, tokenizer, max_length=args.max_length)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, collate_fn=lambda b: collate(b, tokenizer.pad_token_id))
    eval_loader = DataLoader(eval_ds, batch_size=args.batch_size, shuffle=False, collate_fn=lambda b: collate(b, tokenizer.pad_token_id))

    steps_per_epoch = math.ceil(len(train_loader) / max(args.grad_accum, 1))
    total_steps = max(1, steps_per_epoch * args.epochs)
    warmup_steps = int(total_steps * args.warmup_ratio)

    optimizer = torch.optim.AdamW(trainable_params, lr=args.lr, weight_decay=args.weight_decay)
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)

    metadata = {
        "model": args.model,
        "train_file": args.train_file,
        "eval_file": args.eval_file,
        "layer_container": layer_name,
        "n_layers": n_layers,
        "hidden_size": hidden_size,
        "trainable_params": sum(p.numel() for p in trainable_params),
        "epochs": args.epochs,
        "lr": args.lr,
        "objective": "supervised_ce_on_target_tokens",
    }
    print(json.dumps(metadata, indent=2))

    global_step = 0
    model.train()
    optimizer.zero_grad(set_to_none=True)
    for epoch in range(args.epochs):
        for step, batch in enumerate(train_loader):
            batch = {k: v.to(device) for k, v in batch.items()}
            out = model(**batch)
            loss = out.loss / args.grad_accum
            loss.backward()

            if (step + 1) % args.grad_accum == 0:
                torch.nn.utils.clip_grad_norm_(trainable_params, 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                global_step += 1

                if global_step % 10 == 0:
                    print(f"step={global_step} epoch={epoch} train_loss={loss.item() * args.grad_accum:.4f}", flush=True)

                if args.eval_steps and global_step % args.eval_steps == 0:
                    eval_loss, eval_ppl = evaluate_loss(model, eval_loader, device)
                    print(f"[eval] step={global_step} loss={eval_loss:.4f} ppl={eval_ppl:.2f}", flush=True)
                    model.train()

                if args.save_steps and global_step % args.save_steps == 0:
                    save_steering_vectors(model, Path(args.output_dir) / f"checkpoint_step_{global_step}", {**metadata, "step": global_step})

    eval_loss, eval_ppl = evaluate_loss(model, eval_loader, device)
    metadata.update({"final_eval_loss": eval_loss, "final_eval_ppl": eval_ppl})
    save_steering_vectors(model, args.output_dir, metadata)
    print("Saved steering vectors to", args.output_dir)
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
