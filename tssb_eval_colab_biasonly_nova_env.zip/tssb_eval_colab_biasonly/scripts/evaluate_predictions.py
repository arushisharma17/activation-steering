#!/usr/bin/env python3
"""Evaluate TSSB line/diff repair predictions by exact match."""

import argparse
import json
import re
from pathlib import Path
from collections import Counter, defaultdict


def strip_markdown_and_prefixes(s):
    if s is None:
        return ""
    s = str(s).strip()

    # Remove fenced code blocks while preserving contents if possible.
    s = re.sub(r"^```[a-zA-Z0-9_+-]*\n?", "", s)
    s = re.sub(r"\n?```$", "", s)

    # Common prefixes.
    s = re.sub(r"^(Fixed code|Corrected code|Answer|Output)\s*:\s*", "", s, flags=re.I)

    # Remove leading diff marker if present.
    s = re.sub(r"^\+", "", s.strip())
    return s.strip()


def first_code_line_or_join(s):
    s = strip_markdown_and_prefixes(s)
    lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
    if not lines:
        return ""
    if len(lines) == 1:
        return lines[0]
    # For snippets that are tokenized or multi-statement, joining may be closer to TSSB before/after fields.
    return " ".join(lines)


def normalize_ws(s):
    return " ".join(first_code_line_or_join(s).split())


def compact(s):
    return re.sub(r"\s+", "", first_code_line_or_join(s))


def token_edit_distance(a_tokens, b_tokens):
    # Small Levenshtein DP for token lists.
    n, m = len(a_tokens), len(b_tokens)
    if n == 0:
        return m
    if m == 0:
        return n
    prev = list(range(m + 1))
    for i in range(1, n + 1):
        cur = [i] + [0] * m
        for j in range(1, m + 1):
            cost = 0 if a_tokens[i - 1] == b_tokens[j - 1] else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[m]


def token_similarity(pred, target):
    pt = normalize_ws(pred).split()
    tt = normalize_ws(target).split()
    denom = max(len(pt), len(tt), 1)
    return 1.0 - token_edit_distance(pt, tt) / denom


def format_violation(pred):
    if pred is None or not str(pred).strip():
        return True
    s = str(pred)
    if "```" in s:
        return True
    # Multi-line is a violation for strict line-repair, but not necessarily for future function mode.
    lines = [ln for ln in s.splitlines() if ln.strip()]
    return len(lines) > 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gold", required=True, help="Gold eval JSONL, e.g. outputs/tssb_line_repair_eval.jsonl")
    parser.add_argument("--pred", required=True, help="Predictions JSONL with example_id and prediction")
    parser.add_argument("--out", default=None, help="Optional JSON output file")
    args = parser.parse_args()

    gold = {}
    with open(args.gold, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                ex = json.loads(line)
                gold[ex.get("example_id", ex.get("id"))] = ex

    preds = {}
    with open(args.pred, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                p = json.loads(line)
                preds[p.get("example_id", p.get("id"))] = p.get("prediction", "")

    overall = Counter()
    by_pattern = defaultdict(Counter)
    detailed = []

    sim_sum = 0.0
    sim_by_pattern = defaultdict(float)

    for ex_id, ex in gold.items():
        target = ex.get("target") or ex.get("target_code") or ex.get("after") or ""
        pred = preds.get(ex_id, "")

        raw_pred = first_code_line_or_join(pred)
        raw_target = first_code_line_or_join(target)
        raw_exact = raw_pred == raw_target
        norm_exact = normalize_ws(pred) == normalize_ws(target)
        compact_exact = compact(pred) == compact(target)
        sim = token_similarity(pred, target)
        violation = format_violation(pred)

        meta = ex.get("metadata") or {}
        pattern = ex.get("sstub_pattern") or meta.get("sstub_pattern") or "UNKNOWN"

        overall["total"] += 1
        overall["has_prediction"] += int(ex_id in preds)
        overall["raw_exact"] += int(raw_exact)
        overall["norm_exact"] += int(norm_exact)
        overall["compact_exact"] += int(compact_exact)
        overall["format_violation"] += int(violation)
        sim_sum += sim

        by_pattern[pattern]["total"] += 1
        by_pattern[pattern]["has_prediction"] += int(ex_id in preds)
        by_pattern[pattern]["raw_exact"] += int(raw_exact)
        by_pattern[pattern]["norm_exact"] += int(norm_exact)
        by_pattern[pattern]["compact_exact"] += int(compact_exact)
        by_pattern[pattern]["format_violation"] += int(violation)
        sim_by_pattern[pattern] += sim

        detailed.append({
            "example_id": ex_id,
            "sstub_pattern": pattern,
            "raw_exact": raw_exact,
            "norm_exact": norm_exact,
            "compact_exact": compact_exact,
            "token_similarity": sim,
            "format_violation": violation,
            "prediction_clean": raw_pred,
            "target_clean": raw_target,
        })

    total = max(1, overall["total"])
    result = {
        "overall": {
            "total": overall["total"],
            "has_prediction": overall["has_prediction"],
            "raw_exact": overall["raw_exact"] / total,
            "norm_exact": overall["norm_exact"] / total,
            "compact_exact": overall["compact_exact"] / total,
            "format_violation": overall["format_violation"] / total,
            "avg_token_similarity": sim_sum / total,
        },
        "by_sstub_pattern": {},
        "details": detailed,
    }

    for pattern, c in sorted(by_pattern.items(), key=lambda x: -x[1]["total"]):
        n = max(1, c["total"])
        result["by_sstub_pattern"][pattern] = {
            "total": c["total"],
            "has_prediction": c["has_prediction"],
            "raw_exact": c["raw_exact"] / n,
            "norm_exact": c["norm_exact"] / n,
            "compact_exact": c["compact_exact"] / n,
            "format_violation": c["format_violation"] / n,
            "avg_token_similarity": sim_by_pattern[pattern] / n,
        }

    print(json.dumps({k: v for k, v in result.items() if k != "details"}, indent=2))

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("Wrote:", out_path)


if __name__ == "__main__":
    main()
