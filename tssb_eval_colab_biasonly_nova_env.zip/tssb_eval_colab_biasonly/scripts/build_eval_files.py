#!/usr/bin/env python3
"""Build line-level and diff-hunk TSSB evaluation files.

Enhancements over the first version:
- Extracts source-like target_code from the '+' line(s) of the diff.
- Keeps tokenized target as target_tokenized.
- Adds heuristic repair_family and locality_label metadata.
- Adds usable_for_supervised_repair flags for downstream bias-only training.
"""

import argparse
import json
import re
from pathlib import Path
from collections import Counter


def small_localized_prompt(before):
    return f"""You are fixing a small localized bug.
The correct patch is likely a minimal edit to one expression, condition, function call, argument list, lookup, or method name.
Do not rewrite unrelated code.
Return only the corrected code.

Buggy code:
{before}
"""


def base_prompt(before):
    return f"""Fix the bug in the following code.
Return only the corrected code.

Buggy code:
{before}
"""


def family_aware_prompt(before):
    return f"""You are fixing a small localized real-world bug.
The bug is likely one of the following:
- wrong API argument
- missing guard
- type, encoding, or shape mismatch
- wrong lookup path
- method or interface name mismatch
- deterministic ordering issue
- boolean condition error

Make the smallest correct edit.
Return only the corrected code.

Buggy code:
{before}
"""


def oracle_sstub_prompt(before, sstub_pattern):
    return f"""You are fixing a small localized bug.
The SStuB edit pattern is: {sstub_pattern}.
Make the smallest correct edit.
Return only the corrected code.

Buggy code:
{before}
"""


def make_diff_hunk_with_placeholder(diff_text):
    """Replace added lines in a unified diff hunk with <FILL_FIXED_CODE>."""
    if not diff_text:
        return ""
    out = []
    inserted_placeholder = False
    for line in diff_text.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("+") and not line.startswith("+++"):  # added fixed line
            if not inserted_placeholder:
                out.append("+<FILL_FIXED_CODE>")
                inserted_placeholder = True
            # skip extra added lines for now; TSSB is mostly one-line edits.
        else:
            out.append(line)
    return "\n".join(out)


def extract_added_code_from_diff(diff_text):
    """Return source-like fixed code from added lines in a unified diff."""
    if not diff_text:
        return ""
    added = []
    for line in diff_text.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("+") and not line.startswith("+++"):
            added.append(line[1:].rstrip())
    return "\n".join(added).strip()


def extract_removed_code_from_diff(diff_text):
    if not diff_text:
        return ""
    removed = []
    for line in diff_text.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("-") and not line.startswith("---"):
            removed.append(line[1:].rstrip())
    return "\n".join(removed).strip()


def diff_hunk_prompt(diff_hunk):
    return f"""You are fixing a small localized bug in a unified diff hunk.
The line beginning with '-' is buggy.
Replace <FILL_FIXED_CODE> with the corrected code.
Return only the corrected code, without a leading '+'.

Diff hunk:
{diff_hunk}
"""


def compact(s):
    return re.sub(r"\s+", "", s or "")


def identifiers(s):
    return set(re.findall(r"\b[A-Za-z_][A-Za-z_0-9]*\b", s or ""))


def string_literals(s):
    return set(re.findall(r"'[^']*'|\"[^\"]*\"", s or ""))


def classify_repair(before, after, diff_text, sstub_pattern):
    b = before or ""
    a = after or ""
    bc = compact(b)
    ac = compact(a)
    pattern = sstub_pattern or "UNKNOWN"
    reasons = []

    if ".split" in b and ".split" in a and ",1" in ac:
        return "api_argument_contract", "local_inferable", ["string_split_limit"]
    if "re.search" in b and "re.escape" in a:
        return "literal_pattern_escape", "local_inferable", ["regex_escape"]
    if "type=list" in bc and ("type='list'" in ac or 'type="list"' in ac):
        return "nearby_pattern_consistency", "local_inferable", ["argument_spec_type_string"]
    if "hashlib.md5" in b and ".encode" in a:
        return "type_encoding_conversion", "local_inferable", ["string_to_bytes"]
    if ".keys()" in b and "list(" in a:
        return "type_encoding_conversion", "local_inferable", ["dict_view_to_list"]
    if pattern in {"CHANGE_BINARY_OPERATOR", "CHANGE_COMPARISON_OPERATOR"}:
        return "boolean_condition", "local_inferable", ["operator_change"]
    if any(g in a for g in [" is not None", " is None", "hasattr", "isinstance"]):
        return "defensive_guard", "local_inferable", ["guard_added"]
    if pattern in {"SAME_FUNCTION_MORE_ARGS", "SAME_FUNCTION_LESS_ARGS"}:
        return "api_argument_contract", "context_needed", ["call_argument_change"]
    if pattern in {"ADD_METHOD_CALL", "ADD_FUNCTION_AROUND_EXPRESSION"}:
        new_ids = identifiers(a) - identifiers(b)
        common_wrappers = {"list", "tuple", "set", "dict", "str", "int", "float", "bool", "sorted", "len", "range", "encode", "decode", "reshape", "astype", "escape"}
        suspicious = sorted(x for x in new_ids if x not in common_wrappers and x not in {"self", "None", "True", "False", "re"})
        if suspicious:
            return "project_helper_wrapper", "context_needed", ["new_identifier:" + ",".join(suspicious[:5])]
        return "type_encoding_conversion", "local_inferable", ["common_wrapper"]
    if pattern == "SINGLE_TOKEN":
        new_ids = identifiers(a) - identifiers(b)
        new_strs = string_literals(a) - string_literals(b)
        if new_ids or new_strs:
            reasons.append("new_identifier_or_literal")
            return "project_specific_or_lookup", "context_needed", reasons
        return "single_token_local_edit", "context_needed", ["ambiguous_single_token"]

    return "other", "context_needed", ["default"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--line-out", required=True)
    parser.add_argument("--hunk-out", required=True)
    parser.add_argument("--summary-out", required=True)
    parser.add_argument("--require-usable", action="store_true", help="Only write examples marked usable_for_supervised_repair")
    args = parser.parse_args()

    stats = Counter()
    by_pattern = Counter()
    by_project = Counter()
    by_family = Counter()
    by_locality = Counter()

    line_out = Path(args.line_out)
    hunk_out = Path(args.hunk_out)
    summary_out = Path(args.summary_out)
    line_out.parent.mkdir(parents=True, exist_ok=True)
    hunk_out.parent.mkdir(parents=True, exist_ok=True)
    summary_out.parent.mkdir(parents=True, exist_ok=True)

    with open(args.data, "r", encoding="utf-8") as fin, \
         open(line_out, "w", encoding="utf-8") as fline, \
         open(hunk_out, "w", encoding="utf-8") as fhunk:

        for line in fin:
            if not line.strip():
                continue
            ex = json.loads(line)
            stats["total_seen"] += 1
            if args.require_usable and not ex.get("usable_for_supervised_repair"):
                stats["skipped_not_usable"] += 1
                continue

            stats["total_written"] += 1
            by_pattern[ex.get("sstub_pattern", "UNKNOWN")] += 1
            by_project[ex.get("project", "UNKNOWN")] += 1
            stats[f"full_code_status::{ex.get('full_code_status', 'missing')}"] += 1
            if ex.get("before_in_buggy_full_code"):
                stats["before_found"] += 1
            if ex.get("after_in_fixed_full_code"):
                stats["after_found"] += 1

            target_code = extract_added_code_from_diff(ex.get("diff", "")) or ex.get("after") or ""
            buggy_code_from_diff = extract_removed_code_from_diff(ex.get("diff", "")) or ex.get("before") or ""
            repair_family, locality_label, locality_reasons = classify_repair(
                buggy_code_from_diff, target_code, ex.get("diff", ""), ex.get("sstub_pattern")
            )
            by_family[repair_family] += 1
            by_locality[locality_label] += 1

            common = {
                "example_id": ex.get("example_id"),
                "id": f"tssb_{ex.get('example_id')}",
                "project": ex.get("project"),
                "project_url": ex.get("project_url"),
                "file_path": ex.get("file_path"),
                "parent_sha": ex.get("parent_sha"),
                "commit_sha": ex.get("commit_sha"),
                "sstub_pattern": ex.get("sstub_pattern"),
                "repair_family": repair_family,
                "locality_label": locality_label,
                "locality_reasons": locality_reasons,
                "before": ex.get("before"),
                "after": ex.get("after"),
                "target_tokenized": ex.get("after"),
                "target_code": target_code,
                "target": target_code,
                "buggy_code_from_diff": buggy_code_from_diff,
                "diff": ex.get("diff"),
                "full_code_status": ex.get("full_code_status"),
                "before_in_buggy_full_code": ex.get("before_in_buggy_full_code"),
                "after_in_fixed_full_code": ex.get("after_in_fixed_full_code"),
                "usable_for_supervised_repair": bool(ex.get("usable_for_supervised_repair")),
            }

            line_item = dict(common)
            line_item.update({
                "task_type": "line_repair",
                "prompt_base": base_prompt(buggy_code_from_diff or ex.get("before", "")),
                "prompt_localized": small_localized_prompt(buggy_code_from_diff or ex.get("before", "")),
                "prompt_family_aware": family_aware_prompt(buggy_code_from_diff or ex.get("before", "")),
                "prompt_oracle_sstub": oracle_sstub_prompt(buggy_code_from_diff or ex.get("before", ""), ex.get("sstub_pattern", "UNKNOWN")),
                "prompt": small_localized_prompt(buggy_code_from_diff or ex.get("before", "")),
            })
            fline.write(json.dumps(line_item, ensure_ascii=False) + "\n")

            hunk = make_diff_hunk_with_placeholder(ex.get("diff", ""))
            hunk_item = dict(common)
            hunk_item.update({
                "task_type": "diff_hunk_repair",
                "diff_hunk_with_placeholder": hunk,
                "prompt": diff_hunk_prompt(hunk),
            })
            fhunk.write(json.dumps(hunk_item, ensure_ascii=False) + "\n")

    summary = {
        "stats": dict(stats),
        "sstub_pattern_counts": by_pattern.most_common(),
        "repair_family_counts": by_family.most_common(),
        "locality_label_counts": by_locality.most_common(),
        "project_counts_top_50": by_project.most_common(50),
    }
    summary_out.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    print("Wrote:", line_out)
    print("Wrote:", hunk_out)
    print("Wrote:", summary_out)
    print(json.dumps(summary, indent=2, ensure_ascii=False)[:2500])


if __name__ == "__main__":
    main()
