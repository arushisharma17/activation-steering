#!/usr/bin/env python3
"""Create a markdown inspection file showing before/after/diff and nearby buggy code context."""

import argparse
import json
import re
from pathlib import Path


def compact(s):
    return re.sub(r"\s+", "", s or "")


def context_around(full_code, needle, window=8):
    if not full_code or not needle:
        return ""
    lines = full_code.splitlines()
    needle_compact = compact(needle)

    # Try direct single-line containment.
    for i, line in enumerate(lines):
        if needle_compact and needle_compact in compact(line):
            return format_context(lines, i, window)

    # Try multi-line compact containment by progressively joining windows.
    for i in range(len(lines)):
        joined = ""
        for j in range(i, min(len(lines), i + 8)):
            joined += compact(lines[j])
            if needle_compact and needle_compact in joined:
                return format_context(lines, i, window, highlight_end=j)

    return "[before snippet not found]"


def format_context(lines, idx, window, highlight_end=None):
    if highlight_end is None:
        highlight_end = idx
    start = max(0, idx - window)
    end = min(len(lines), highlight_end + window + 1)
    out = []
    for j in range(start, end):
        marker = ">>" if idx <= j <= highlight_end else "  "
        out.append(f"{marker} {j+1}: {lines[j]}")
    return "\n".join(out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--max-examples", type=int, default=100)
    args = parser.parse_args()

    examples = []
    with open(args.data, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            ex = json.loads(line)
            if ex.get("full_code_status") == "ok":
                examples.append(ex)
            if len(examples) >= args.max_examples:
                break

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with open(out_path, "w", encoding="utf-8") as out:
        out.write("# TSSB Context Inspection\n\n")
        out.write("This file samples examples from the enriched TSSB data and shows the localized before/after edit plus nearby buggy full-file context.\n\n")
        for ex in examples:
            out.write(f"# Example {ex.get('example_id')} | {ex.get('project')} | {ex.get('sstub_pattern')}\n\n")
            out.write(f"File: `{ex.get('file_path')}`\n\n")
            out.write(f"Parent SHA / buggy: `{ex.get('parent_sha')}`\n\n")
            out.write(f"Commit SHA / fixed: `{ex.get('commit_sha')}`\n\n")

            out.write("## Before\n")
            out.write("```python\n" + str(ex.get("before", "")) + "\n```\n\n")

            out.write("## After\n")
            out.write("```python\n" + str(ex.get("after", "")) + "\n```\n\n")

            out.write("## Diff\n")
            out.write("```diff\n" + str(ex.get("diff", "")) + "\n```\n\n")

            out.write("## Buggy context\n")
            out.write("```python\n" + context_around(ex.get("buggy_full_code", ""), ex.get("before", ""), window=args.window) + "\n```\n\n")
            out.write("---\n\n")

    print("Wrote:", out_path)


if __name__ == "__main__":
    main()
