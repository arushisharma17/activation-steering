#!/usr/bin/env python3
"""Create dummy predictions for smoke-testing the evaluator.

Modes:
- copy_before: intentionally poor baseline, predicts the buggy snippet.
- oracle_after: sanity-check upper bound, predicts the target.
"""

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gold", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--mode", choices=["copy_before", "oracle_after"], default="copy_before")
    args = parser.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    with open(args.gold, "r", encoding="utf-8") as fin, open(out, "w", encoding="utf-8") as fout:
        for line in fin:
            if not line.strip():
                continue
            ex = json.loads(line)
            if args.mode == "copy_before":
                pred = ex.get("before", "")
            else:
                pred = ex.get("target", ex.get("after", ""))
            fout.write(json.dumps({"example_id": ex["example_id"], "prediction": pred}) + "\n")

    print("Wrote:", out)


if __name__ == "__main__":
    main()
