#!/usr/bin/env python3
"""Fetch buggy/fixed full files for TSSB-style entries from Git commits.

Robust to non-UTF-8 files returned by `git show`.

Expected fields:
- project_url
- parent_sha     -> buggy commit/version
- commit_sha     -> fixed commit/version
- file_path
- before         -> localized buggy snippet
- after          -> localized fixed snippet
"""

import argparse
import json
import re
import subprocess
from pathlib import Path
from urllib.parse import urlparse
from collections import Counter


def decode_bytes(data):
    """Decode subprocess byte output defensively.

    Some old source files in GitHub projects are not valid UTF-8. We mainly need
    these files for locating snippets and extracting context, so a latin-1/cp1252
    fallback is preferable to crashing the whole pipeline.
    """
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            pass
    return data.decode("utf-8", errors="replace")


def run(cmd, cwd=None, timeout=300):
    try:
        res = subprocess.run(
            cmd,
            cwd=cwd,
            text=False,  # capture bytes; decode manually
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
        res.stdout = decode_bytes(res.stdout)
        res.stderr = decode_bytes(res.stderr)
        return res
    except subprocess.TimeoutExpired as e:
        class Result:
            returncode = 124
            stdout = ""
            stderr = f"TimeoutExpired: {e}"
        return Result()
    except Exception as e:
        class Result:
            returncode = 125
            stdout = ""
            stderr = f"Exception: {type(e).__name__}: {e}"
        return Result()


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", s)


def repo_name_from_url(url):
    path = urlparse(url).path.strip("/")
    if path.endswith(".git"):
        path = path[:-4]
    return safe_name(path.replace("/", "__"))


def clone_or_fetch(url, repo_dir):
    repo_path = repo_dir / repo_name_from_url(url)

    if not repo_path.exists():
        print(f"[clone] {url}", flush=True)
        # --filter=blob:none reduces clone size but git show will lazily fetch needed blobs.
        res = run(["git", "clone", "--no-checkout", "--filter=blob:none", url, str(repo_path)], timeout=600)
        if res.returncode != 0:
            print("[clone failed]", url, flush=True)
            print((res.stderr or "")[:800], flush=True)
            return None, res.stderr
    else:
        res = run(["git", "fetch", "--all", "--tags"], cwd=repo_path, timeout=600)
        if res.returncode != 0:
            print("[fetch warning]", url, flush=True)
            print((res.stderr or "")[:500], flush=True)

    return repo_path, None


def git_show(repo_path, sha, file_path):
    res = run(["git", "show", f"{sha}:{file_path}"], cwd=repo_path, timeout=300)
    if res.returncode != 0:
        return None, (res.stderr or "git_show_failed")
    return res.stdout, None


def compact(s):
    return re.sub(r"\s+", "", s or "")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--repo-dir", default="repos_tssb")
    parser.add_argument("--max-examples", type=int, default=None)
    args = parser.parse_args()

    data_path = Path(args.data)
    out_path = Path(args.out)
    repo_dir = Path(args.repo_dir)
    repo_dir.mkdir(parents=True, exist_ok=True)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    stats = Counter()
    required = ["project_url", "parent_sha", "commit_sha", "file_path", "before", "after"]

    with open(data_path, "r", encoding="utf-8") as fin, open(out_path, "w", encoding="utf-8") as fout:
        for i, line in enumerate(fin):
            if args.max_examples is not None and i >= args.max_examples:
                break
            if not line.strip():
                continue

            try:
                ex = json.loads(line)
            except json.JSONDecodeError:
                stats["json_decode_error"] += 1
                continue

            ex["example_id"] = i
            missing = [k for k in required if k not in ex]
            if missing:
                ex["full_code_status"] = "missing_required_fields"
                ex["missing_fields"] = missing
                ex["usable_for_supervised_repair"] = False
                stats["missing_required_fields"] += 1
                fout.write(json.dumps(ex, ensure_ascii=False) + "\n")
                continue

            repo, clone_err = clone_or_fetch(ex["project_url"], repo_dir)
            if repo is None:
                ex["full_code_status"] = "clone_failed"
                ex["clone_error"] = (clone_err or "")[:1000]
                ex["usable_for_supervised_repair"] = False
                stats["clone_failed"] += 1
                fout.write(json.dumps(ex, ensure_ascii=False) + "\n")
                continue

            buggy_code, buggy_err = git_show(repo, ex["parent_sha"], ex["file_path"])
            fixed_code, fixed_err = git_show(repo, ex["commit_sha"], ex["file_path"])

            if buggy_code is None:
                ex["full_code_status"] = "buggy_git_show_failed"
                ex["buggy_git_error"] = (buggy_err or "")[:1000]
                ex["usable_for_supervised_repair"] = False
                stats["buggy_git_show_failed"] += 1
            elif fixed_code is None:
                ex["full_code_status"] = "fixed_git_show_failed"
                ex["fixed_git_error"] = (fixed_err or "")[:1000]
                ex["usable_for_supervised_repair"] = False
                stats["fixed_git_show_failed"] += 1
            else:
                before_found = compact(ex.get("before")) in compact(buggy_code)
                after_found = compact(ex.get("after")) in compact(fixed_code)
                ex["full_code_status"] = "ok"
                ex["buggy_full_code"] = buggy_code
                ex["fixed_full_code"] = fixed_code
                ex["before_in_buggy_full_code"] = before_found
                ex["after_in_fixed_full_code"] = after_found
                ex["usable_for_supervised_repair"] = bool(
                    before_found and after_found and ex.get("before") and ex.get("after") and ex.get("before") != ex.get("after")
                )
                stats["ok"] += 1
                if ex["usable_for_supervised_repair"]:
                    stats["usable_for_supervised_repair"] += 1

            fout.write(json.dumps(ex, ensure_ascii=False) + "\n")

            if i % 25 == 0:
                print(f"[progress] {i} examples | {dict(stats)}", flush=True)

    print("Wrote:", out_path)
    print("Stats:", dict(stats))


if __name__ == "__main__":
    main()
