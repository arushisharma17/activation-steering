# Colab command recipe

Upload:

```python
from google.colab import files
files.upload()  # upload tssb_eval_colab_biasonly.zip and filtered2.jsonl
```

Unzip:

```bash
!unzip -q tssb_eval_colab_biasonly.zip -d /content/
%cd /content/tssb_eval_colab_biasonly
```

Dry run:

```bash
!python run_colab_pipeline.py --data /content/filtered2.jsonl --max-examples 100 --require-usable
```

Full run:

```bash
!python run_colab_pipeline.py --data /content/filtered2.jsonl --require-usable
```

Check outputs:

```bash
!head -1 outputs/supervised/tssb_supervised_train.jsonl | python -m json.tool
!cat outputs/supervised/tssb_supervised_summary.json
```

Smoke-test evaluator with oracle and copy-before dummy predictions:

```bash
!python scripts/make_dummy_predictions.py --gold outputs/tssb_diff_hunk_eval.jsonl --out outputs/pred_oracle.jsonl --mode oracle_after
!python scripts/evaluate_predictions.py --gold outputs/tssb_diff_hunk_eval.jsonl --pred outputs/pred_oracle.jsonl --out outputs/eval_oracle.json
```

Bias-only training is better on a GPU runtime or Nova:

```bash
!pip install -q transformers accelerate
!python scripts/train_bias_only_tssb.py \
  --model Qwen/Qwen2.5-Coder-7B-Instruct \
  --train-file outputs/supervised/tssb_supervised_train.jsonl \
  --eval-file outputs/supervised/tssb_supervised_dev.jsonl \
  --output-dir outputs/bias_only_qwen_tssb \
  --epochs 1 --batch-size 1 --grad-accum 8 --lr 1e-2 --max-length 2048 --dtype bf16
```
