#!/bin/bash

#SBATCH --time=5-00:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --gres=gpu:a100
#SBATCH --mem=128G
#SBATCH --job-name="tssb_bias_train"
#SBATCH --mail-user=arushi17@iastate.edu
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL
#SBATCH --output="logs/slurm-tssb-bias-train-%j.out"

set -euo pipefail

# Nova environment setup: paths, caches, CUDA, and Python env.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/nova_env.sh"

# Usage:
#   sbatch slurm/01_train_bias_only_tssb.sh
# Optional overrides:
#   MODEL=Qwen/Qwen2.5-Coder-1.5B-Instruct EPOCHS=1 MAX_LENGTH=1024 sbatch ...
#   INIT_STEERING=/path/to/steering_vectors.pt sbatch ...

ROOT="${ROOT:-$TSSB_ROOT}"
MODEL="${MODEL:-Qwen/Qwen2.5-Coder-7B-Instruct}"
SUP_DIR="${SUP_DIR:-$ROOT/outputs/supervised_all_random}"
TRAIN_FILE="${TRAIN_FILE:-$SUP_DIR/tssb_supervised_train.jsonl}"
EVAL_FILE="${EVAL_FILE:-$SUP_DIR/tssb_supervised_dev.jsonl}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT/outputs/bias_only_qwen_tssb}"
EPOCHS="${EPOCHS:-1}"
BATCH_SIZE="${BATCH_SIZE:-1}"
GRAD_ACCUM="${GRAD_ACCUM:-8}"
LR="${LR:-1e-2}"
MAX_LENGTH="${MAX_LENGTH:-2048}"
DTYPE="${DTYPE:-bf16}"
EVAL_STEPS="${EVAL_STEPS:-100}"
SAVE_STEPS="${SAVE_STEPS:-500}"
INIT_STEERING="${INIT_STEERING:-}"
cd "$ROOT"
mkdir -p logs "$OUTPUT_DIR" "$HF_HOME"

echo "[INFO] ROOT=$ROOT"
echo "[INFO] MODEL=$MODEL"
echo "[INFO] TRAIN_FILE=$TRAIN_FILE"
echo "[INFO] EVAL_FILE=$EVAL_FILE"
echo "[INFO] OUTPUT_DIR=$OUTPUT_DIR"
echo "[INFO] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-<unset>}"
nvidia-smi || true

ARGS=(
  scripts/train_bias_only_tssb.py
  --model "$MODEL"
  --train-file "$TRAIN_FILE"
  --eval-file "$EVAL_FILE"
  --output-dir "$OUTPUT_DIR"
  --epochs "$EPOCHS"
  --batch-size "$BATCH_SIZE"
  --grad-accum "$GRAD_ACCUM"
  --lr "$LR"
  --max-length "$MAX_LENGTH"
  --dtype "$DTYPE"
  --eval-steps "$EVAL_STEPS"
  --save-steps "$SAVE_STEPS"
)
if [[ -n "$INIT_STEERING" ]]; then
  ARGS+=(--init-steering "$INIT_STEERING")
fi

echo "[RUN] $PYTHON ${ARGS[*]}"
"$PYTHON" "${ARGS[@]}"

echo "[INFO] Done. Outputs in $OUTPUT_DIR"
ls -lh "$OUTPUT_DIR" || true
