#!/bin/bash

#SBATCH --time=5-00:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --gres=gpu:a100
#SBATCH --mem=128G
#SBATCH --job-name="tssb_prepare"
#SBATCH --mail-user=arushi17@iastate.edu
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL
#SBATCH --output="logs/slurm-tssb-prepare-%j.out"

set -euo pipefail

# Nova environment setup: paths, caches, CUDA, and Python env.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/nova_env.sh"

# Usage:
#   sbatch slurm/00_prepare_tssb_supervised.sh
# Optional overrides:
#   ROOT=/lustre/.../tssb_eval_colab_biasonly \
#   DATA=/lustre/.../filtered-2.jsonl \
#   MAX_EXAMPLES=5000 \
#   SPLIT_MODE=random \
#   sbatch slurm/00_prepare_tssb_supervised.sh

ROOT="${ROOT:-$TSSB_ROOT}"
DATA="${DATA:-$PROJECT_ROOT/data/tssb_data_3M/derived/filtered-2.jsonl}"
OUT_DIR="${OUT_DIR:-$ROOT/outputs}"
REPO_DIR="${REPO_DIR:-$ROOT/repos_tssb}"
PYTHON="${PYTHON:-python}"
MAX_EXAMPLES="${MAX_EXAMPLES:-}"
SPLIT_MODE="${SPLIT_MODE:-random}"
SEED="${SEED:-42}"
REQUIRE_USABLE="${REQUIRE_USABLE:-0}"
SKIP_FETCH="${SKIP_FETCH:-0}"

cd "$ROOT"
mkdir -p logs "$OUT_DIR" "$REPO_DIR"

echo "[INFO] ROOT=$ROOT"
echo "[INFO] DATA=$DATA"
echo "[INFO] OUT_DIR=$OUT_DIR"
echo "[INFO] REPO_DIR=$REPO_DIR"
echo "[INFO] MAX_EXAMPLES=${MAX_EXAMPLES:-<none>}"
echo "[INFO] SPLIT_MODE=$SPLIT_MODE"
echo "[INFO] REQUIRE_USABLE=$REQUIRE_USABLE"
echo "[INFO] SKIP_FETCH=$SKIP_FETCH"

FETCH_OUT="$OUT_DIR/tssb_with_full_code.jsonl"
LINE_OUT="$OUT_DIR/tssb_line_repair_eval_all.jsonl"
HUNK_OUT="$OUT_DIR/tssb_diff_hunk_eval_all.jsonl"
SUMMARY_OUT="$OUT_DIR/dataset_summary_all.json"
SUP_OUT="$OUT_DIR/supervised_all_${SPLIT_MODE}"

if [[ "$SKIP_FETCH" == "1" && -s "$FETCH_OUT" ]]; then
  echo "[INFO] Skipping fetch; using existing $FETCH_OUT"
else
  FETCH_ARGS=(
    scripts/fetch_full_code.py
    --data "$DATA"
    --out "$FETCH_OUT"
    --repo-dir "$REPO_DIR"
  )
  if [[ -n "$MAX_EXAMPLES" ]]; then
    FETCH_ARGS+=(--max-examples "$MAX_EXAMPLES")
  fi
  echo "[RUN] $PYTHON ${FETCH_ARGS[*]}"
  "$PYTHON" "${FETCH_ARGS[@]}"
fi

BUILD_ARGS=(
  scripts/build_eval_files.py
  --data "$FETCH_OUT"
  --line-out "$LINE_OUT"
  --hunk-out "$HUNK_OUT"
  --summary-out "$SUMMARY_OUT"
)
if [[ "$REQUIRE_USABLE" == "1" ]]; then
  BUILD_ARGS+=(--require-usable)
fi

echo "[RUN] $PYTHON ${BUILD_ARGS[*]}"
"$PYTHON" "${BUILD_ARGS[@]}"

PREP_ARGS=(
  scripts/prepare_supervised_tssb.py
  --data "$HUNK_OUT"
  --out-dir "$SUP_OUT"
  --split-mode "$SPLIT_MODE"
  --seed "$SEED"
  --target-field target_code
)
if [[ "$REQUIRE_USABLE" == "1" ]]; then
  PREP_ARGS+=(--require-usable)
fi

echo "[RUN] $PYTHON ${PREP_ARGS[*]}"
"$PYTHON" "${PREP_ARGS[@]}"

echo "[INFO] Counts:"
wc -l "$FETCH_OUT" "$HUNK_OUT" "$SUP_OUT"/*.jsonl || true

echo "[INFO] Summary:"
cat "$SUP_OUT/tssb_supervised_summary.json" || true
