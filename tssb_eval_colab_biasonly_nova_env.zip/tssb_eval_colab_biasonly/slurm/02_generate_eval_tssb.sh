#!/bin/bash

#SBATCH --time=5-00:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --gres=gpu:a100
#SBATCH --mem=128G
#SBATCH --job-name="tssb_bias_eval"
#SBATCH --mail-user=arushi17@iastate.edu
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL
#SBATCH --output="logs/slurm-tssb-bias-eval-%j.out"

set -euo pipefail

# Nova environment setup: paths, caches, CUDA, and Python env.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/nova_env.sh"

# Usage:
#   sbatch slurm/02_generate_eval_tssb.sh
# Optional overrides:
#   STEERING=none sbatch ...        # base model generation
#   MAX_EXAMPLES=100 sbatch ...     # smoke test

ROOT="${ROOT:-$TSSB_ROOT}"
MODEL="${MODEL:-Qwen/Qwen2.5-Coder-7B-Instruct}"
SUP_DIR="${SUP_DIR:-$ROOT/outputs/supervised_all_random}"
TEST_FILE="${TEST_FILE:-$SUP_DIR/tssb_supervised_test.jsonl}"
STEERING="${STEERING:-$ROOT/outputs/bias_only_qwen_tssb/steering_vectors.pt}"
PRED_OUT="${PRED_OUT:-$ROOT/outputs/preds_bias_only_test.jsonl}"
EVAL_OUT="${EVAL_OUT:-$ROOT/outputs/eval_bias_only_test.json}"
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-80}"
DTYPE="${DTYPE:-bf16}"
MAX_EXAMPLES="${MAX_EXAMPLES:-}"
cd "$ROOT"
mkdir -p logs "$(dirname "$PRED_OUT")" "$HF_HOME"

echo "[INFO] ROOT=$ROOT"
echo "[INFO] MODEL=$MODEL"
echo "[INFO] TEST_FILE=$TEST_FILE"
echo "[INFO] STEERING=$STEERING"
echo "[INFO] PRED_OUT=$PRED_OUT"
echo "[INFO] EVAL_OUT=$EVAL_OUT"
nvidia-smi || true

GEN_ARGS=(
  scripts/generate_with_bias_only.py
  --model "$MODEL"
  --data "$TEST_FILE"
  --out "$PRED_OUT"
  --max-new-tokens "$MAX_NEW_TOKENS"
  --dtype "$DTYPE"
)

if [[ "$STEERING" != "none" && -n "$STEERING" ]]; then
  GEN_ARGS+=(--steering "$STEERING")
fi
if [[ -n "$MAX_EXAMPLES" ]]; then
  GEN_ARGS+=(--max-examples "$MAX_EXAMPLES")
fi

echo "[RUN] $PYTHON ${GEN_ARGS[*]}"
"$PYTHON" "${GEN_ARGS[@]}"

echo "[RUN] $PYTHON scripts/evaluate_predictions.py --gold $TEST_FILE --pred $PRED_OUT --out $EVAL_OUT"
"$PYTHON" scripts/evaluate_predictions.py --gold "$TEST_FILE" --pred "$PRED_OUT" --out "$EVAL_OUT"

echo "[INFO] Done."
cat "$EVAL_OUT" | head -100 || true
