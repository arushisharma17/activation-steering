#!/bin/bash
# Shared Nova environment setup for TSSB bias-only steering jobs.
# Override any variable at sbatch time with --export=ALL,VAR=value.

########################################
# User / project paths
########################################
BASE_ROOT="${BASE_ROOT:-/lustre/hdd/LAS/jannesar-lab/arushi}"
PROJECT_ROOT="${PROJECT_ROOT:-${BASE_ROOT}/activation-steering}"
TSSB_ROOT="${TSSB_ROOT:-${BASE_ROOT}/tssb_eval_colab_biasonly}"

CACHE_DIR="${CACHE_DIR:-${PROJECT_ROOT}/models}"
MCQ_CACHE="${MCQ_CACHE:-${PROJECT_ROOT}/mcq_cache}"
RESULTS_ROOT="${RESULTS_ROOT:-${PROJECT_ROOT}/tmp/mcq_eval}"

########################################
# Cache / runtime environment
########################################
export MPLCONFIGDIR="${MPLCONFIGDIR:-${BASE_ROOT}/matplotlib}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-${BASE_ROOT}/cache}"
export TRITON_CACHE_DIR="${TRITON_CACHE_DIR:-${BASE_ROOT}/cache/triton}"
export HF_HOME="${HF_HOME:-${BASE_ROOT}}"
export HF_CACHE="${HF_CACHE:-${CACHE_DIR}}"
export TRANSFORMERS_CACHE="${TRANSFORMERS_CACHE:-${CACHE_DIR}}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-${BASE_ROOT}/cache/huggingface/datasets}"
export TOKENIZERS_PARALLELISM="${TOKENIZERS_PARALLELISM:-false}"

export CUDA_LAUNCH_BLOCKING="${CUDA_LAUNCH_BLOCKING:-1}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

mkdir -p "$MPLCONFIGDIR" "$XDG_CACHE_HOME" "$TRITON_CACHE_DIR" "$CACHE_DIR" "$MCQ_CACHE" "$RESULTS_ROOT" "$HF_DATASETS_CACHE"

########################################
# Python environment
########################################
cd "${BASE_ROOT}"
if [[ -f "${BASE_ROOT}/myenv/bin/activate" ]]; then
  source "${BASE_ROOT}/myenv/bin/activate"
elif [[ -f "${BASE_ROOT}/.venv/bin/activate" ]]; then
  source "${BASE_ROOT}/.venv/bin/activate"
else
  echo "[WARN] No myenv/.venv found under ${BASE_ROOT}; using current Python environment."
fi

PYTHON="${PYTHON:-python}"
export BASE_ROOT PROJECT_ROOT TSSB_ROOT CACHE_DIR MCQ_CACHE RESULTS_ROOT PYTHON
