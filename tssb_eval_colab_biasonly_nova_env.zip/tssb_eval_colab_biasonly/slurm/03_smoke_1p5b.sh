#!/bin/bash

#SBATCH --time=5-00:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --gres=gpu:a100
#SBATCH --mem=128G
#SBATCH --job-name="tssb_smoke15"
#SBATCH --mail-user=arushi17@iastate.edu
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL
#SBATCH --output="logs/slurm-tssb-smoke15-%j.out"

set -euo pipefail

# Nova environment setup: paths, caches, CUDA, and Python env.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/nova_env.sh"

# End-to-end smoke test with a smaller model and small train/dev subsets.
# Assumes outputs/supervised_all_random already exists.

ROOT="${ROOT:-$TSSB_ROOT}"
MODEL="${MODEL:-Qwen/Qwen2.5-Coder-1.5B-Instruct}"
SUP_DIR="${SUP_DIR:-$ROOT/outputs/supervised_all_random}"
SMOKE_DIR="${SMOKE_DIR:-$ROOT/outputs/smoke_splits}"
OUT_DIR="${OUT_DIR:-$ROOT/outputs/bias_only_qwen15_tssb_smoke}"
cd "$ROOT"
mkdir -p logs "$SMOKE_DIR" "$OUT_DIR" "$HF_HOME"

head -n 200 "$SUP_DIR/tssb_supervised_train.jsonl" > "$SMOKE_DIR/tssb_train_200.jsonl"
head -n 50 "$SUP_DIR/tssb_supervised_dev.jsonl" > "$SMOKE_DIR/tssb_dev_50.jsonl"
head -n 50 "$SUP_DIR/tssb_supervised_test.jsonl" > "$SMOKE_DIR/tssb_test_50.jsonl"

nvidia-smi || true

"$PYTHON" scripts/train_bias_only_tssb.py \
  --model "$MODEL" \
  --train-file "$SMOKE_DIR/tssb_train_200.jsonl" \
  --eval-file "$SMOKE_DIR/tssb_dev_50.jsonl" \
  --output-dir "$OUT_DIR" \
  --epochs 1 \
  --batch-size 1 \
  --grad-accum 8 \
  --lr 1e-2 \
  --max-length 1024 \
  --dtype bf16 \
  --eval-steps 10 \
  --save-steps 100

"$PYTHON" scripts/generate_with_bias_only.py \
  --model "$MODEL" \
  --data "$SMOKE_DIR/tssb_test_50.jsonl" \
  --steering "$OUT_DIR/steering_vectors.pt" \
  --out "$ROOT/outputs/preds_smoke_50.jsonl" \
  --max-new-tokens 80 \
  --dtype bf16

"$PYTHON" scripts/evaluate_predictions.py \
  --gold "$SMOKE_DIR/tssb_test_50.jsonl" \
  --pred "$ROOT/outputs/preds_smoke_50.jsonl" \
  --out "$ROOT/outputs/eval_smoke_50.json"
